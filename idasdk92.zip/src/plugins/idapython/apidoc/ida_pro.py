
def str2user(str):
    """
    Insert C-style escape characters to string

    :param str: the input string
    :returns: new string with escape characters inserted, or None
    """
    pass
