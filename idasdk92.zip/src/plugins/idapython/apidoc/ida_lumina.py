
def split_metadata(metadata: bytes) -> dict:
    """
    Split the metadata blob into a set of KVP's

    :param metadata: a metadata blob
    :returns: a set of KVP's
    """
    pass
