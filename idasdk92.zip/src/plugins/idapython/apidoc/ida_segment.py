
def get_defsr(s, reg):
    """
    Deprecated, use instead:
        value = s.defsr[reg]
    """
    pass


def set_defsr(s, reg, value):
    """
    Deprecated, use instead:
        s.defsr[reg] = value
    """
    pass
