{
    "repl_line" : [
        ("class casm_t(ida_pro.uintvec_t):", "class casm_t(ida_pro.eavec_t):"),
        ("class casm_t(ida_pro.uint64vec_t):", "class casm_t(ida_pro.eavec_t):"),
    ],
}
