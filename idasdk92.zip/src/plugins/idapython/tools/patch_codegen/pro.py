{
    "qexit" : [
        ("repl_text", ("resultobj = SWIG_Py_Void();", " // resultobj = SWIG_Py_Void();")),
        ("repl_text", ("return resultobj;", "qnotused(resultobj); // return resultobj;")),
    ],
}
