{
   "SwigDirector_user_defined_prefix_t::get_user_defined_prefix" : [
        ("spontaneous_callback_call", (
            True,                              # add GIL lock
            "  swig::SwigVar_PyObject obj0;",  # try anchor
            "}"                                # catch anchor
        )),
    ],
}
