{
    "requires_idb" : [
        ".*",
        "-is_type_.*",
        "-get_base_type",
        "-get_type_flags",
        "-get_full_type",
        "-is_typeid_last",
        "-is_tah_byte",
        "-is_sdacl_byte",
        "-get_cc",
        "-is_.*_cc",
        "-convert_pt_flags_to_hti",
    ],
}
