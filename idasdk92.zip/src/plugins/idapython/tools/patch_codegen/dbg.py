{

    "SwigDirector_DBG_Hooks::SwigDirector_DBG_Hooks" : [
        ("maybe_collect_director_fixed_method_set", None),
    ],
}
