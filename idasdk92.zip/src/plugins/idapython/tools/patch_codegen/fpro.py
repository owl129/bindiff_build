{
    "new_qfile_t" : [
        ("repl_text", (
            "PyObject *argv[2];",
            "PyObject *argv[2] = {0, 0};")),
    ]
}
