{
    "next_that" : [
        ("nullptr_result_on_py_error", None),
    ],
    "prev_that" : [
        ("nullptr_result_on_py_error", None),
    ],
}
