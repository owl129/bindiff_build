{
    "func_item_iterator_t___next__" : [
        ("nullptr_result_on_py_error", None),
    ],
    "func_item_iterator_t_prev" : [
        ("nullptr_result_on_py_error", None),
    ],
    "func_item_iterator_t_succ" : [
        ("nullptr_result_on_py_error", None),
    ],
}


