{
    "SwigDirector_drawable_graph_t::nrect" : [
        ("repl_text", ("return", "qnotused(c_result); qnotused(n); // return")),
    ],
    "SwigDirector_drawable_graph_t::get_edge" : [
        ("repl_text", ("return", "qnotused(c_result); qnotused(e); // return")),
    ],
    "SwigDirector_drawable_graph_t::clone" : [
        ("repl_text", ("return", "qnotused(c_result); // return")),
    ],
    "SwigDirector_interactive_graph_t::get_edge" : [
        ("repl_text", ("return", "qnotused(c_result); qnotused(e); // return")),
    ],
    "SwigDirector_interactive_graph_t::clone" : [
        ("repl_text", ("return", "qnotused(c_result); // return")),
    ],
}

