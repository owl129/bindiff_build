{
    "new_idc_value_t" : [
        ("repl_text", (
            "PyObject *argv[2];",
            "PyObject *argv[2] = {0, 0};")),
    ],
    "exec_system_script__SWIG_0" : [
        ("release_gil_around", "exec_system_script(")
    ],
    "exec_system_script__SWIG_1" : [
        ("release_gil_around", "exec_system_script(")
    ],
}
