
recipe = {
}

default_rtype = "void"
