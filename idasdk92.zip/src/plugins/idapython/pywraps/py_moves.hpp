#ifndef __PYMOVES__
#define __PYMOVES__
//<inline(py_moves)>
//</inline(py_moves)>
#endif
