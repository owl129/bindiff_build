#<pycode(py_moves)>
import ida_kernwin
#</pycode(py_moves)>
