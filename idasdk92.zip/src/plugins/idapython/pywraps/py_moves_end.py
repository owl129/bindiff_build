#<pycode(py_moves_end)>
bookmarks_t_erase = bookmarks_t.erase
bookmarks_t_find_index = bookmarks_t.find_index
bookmarks_t_get = bookmarks_t.get
bookmarks_t_get_desc = bookmarks_t.get_desc
bookmarks_t_get_dirtree_id = bookmarks_t.get_dirtree_id
bookmarks_t_mark = bookmarks_t.mark
bookmarks_t_size = bookmarks_t.size
#</pycode(py_moves_end)>
