#<pycode(py_netnode_end)>
netnode_exist = netnode.exist
#</pycode(py_netnode_end)>
