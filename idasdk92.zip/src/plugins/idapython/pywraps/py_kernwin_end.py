#<pycode(py_kernwin_end)>
place_t_as_idaplace_t = place_t.as_idaplace_t
place_t_as_simpleline_place_t = place_t.as_simpleline_place_t
place_t_as_tiplace_t = place_t.as_tiplace_t
#</pycode(py_kernwin_end)>
