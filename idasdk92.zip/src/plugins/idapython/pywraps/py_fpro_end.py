#<pycode(py_fpro_end)>
qfile_t_from_fp = qfile_t.from_fp
qfile_t_from_capsule = qfile_t.from_capsule
qfile_t_tmpfile = qfile_t.tmpfile
#</pycode(py_fpro_end)>
