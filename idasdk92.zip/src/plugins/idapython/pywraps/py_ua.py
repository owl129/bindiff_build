#<pycode(py_ua)>
ua_mnem = print_insn_mnem
#</pycode(py_ua)>
