
// /*
//   TODO's
//   * `start_ea` -> `range_start`
//   * `end_ea` -> `range_size`
//   * parse_binpat_str => warning in case of error
//   * make start_ea the 1st argument?
//   * "4f fd" fails parsing
//   * masks don't honor the bit granularity: anything non-0 is considered as a match
//  */


//<code(py_bytes_find_bytes)>
//</code(py_bytes_find_bytes)>


//<inline(py_bytes_find_bytes)>
inline bytevec_t __to_bytevec(const bytevec_t &in)
{
  return in;
}
//</inline(py_bytes_find_bytes)>

