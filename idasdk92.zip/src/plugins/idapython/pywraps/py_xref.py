
#<pycode(py_xref)>

import ida_idaapi
ida_idaapi._listify_types(
        casevec_t)

XREF_ALL = XREF_FLOW
XREF_FAR = XREF_NOFLOW

#</pycode(py_xref)>
