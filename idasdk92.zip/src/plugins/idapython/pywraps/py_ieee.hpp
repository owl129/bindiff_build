//<inline(py_ieee)>
typedef bytevec_t bytevec16_t;
//</inline(py_ieee)>

