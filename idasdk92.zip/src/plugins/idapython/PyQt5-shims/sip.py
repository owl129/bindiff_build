# Placeholder

def wrapinstance(addr, type):
    import shiboken6.Shiboken
    return shiboken6.Shiboken.wrapInstance(addr, type)

